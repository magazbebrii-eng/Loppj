package com.example.pangorushbot

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.nio.ByteBuffer

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastActionAt = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, Notification.Builder(this, "pudge_bot")
            .setContentTitle("Pudge Rider Bot")
            .setContentText("Визуальный автопилот активен")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection == null) {
            val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
            val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
            val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = pm.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))
            startCapture()
        }
        return START_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        val density = dm.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "PudgeRiderCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )
        reader?.setOnImageAvailableListener({ r ->
            if (BotState.status != BotStatus.RUNNING) {
                r.acquireLatestImage()?.close(); return@setOnImageAvailableListener
            }
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer: ByteBuffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val full = Bitmap.createBitmap(
                    width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                )
                buffer.rewind(); full.copyPixelsFromBuffer(buffer)
                val bitmap = if (full.width != width) Bitmap.createBitmap(full, 0, 0, width, height) else full

                val d = PudgeAnalyzer.decide(bitmap, BotState.sensitivity)
                val now = System.currentTimeMillis()
                val cooldown = when {
                    d.airborne -> maxOf(90L, BotState.jumpDelayMs.toLong())
                    d.confidence > .65f -> maxOf(120L, BotState.jumpDelayMs.toLong())
                    else -> maxOf(180L, BotState.jumpDelayMs.toLong())
                }
                if (d.action != PudgeAnalyzer.Action.NONE && now - lastActionAt >= cooldown) {
                    lastActionAt = now
                    when (d.action) {
                        PudgeAnalyzer.Action.LEFT -> BotAccessibilityService.instance?.pressLeft()
                        PudgeAnalyzer.Action.RIGHT -> BotAccessibilityService.instance?.pressRight()
                        PudgeAnalyzer.Action.NONE -> Unit
                    }
                }
                if (bitmap !== full) bitmap.recycle()
                full.recycle()
            } finally { image.close() }
        }, Handler(Looper.getMainLooper()))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("pudge_bot", "Pudge Rider Bot", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        PudgeAnalyzer.reset()
        reader?.close(); display?.release(); projection?.stop()
        reader = null; display = null; projection = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
