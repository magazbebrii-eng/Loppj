package com.example.pangorushbot

import android.graphics.Bitmap
import kotlin.math.*

/**
 * Visual controller tuned from the supplied Pudge Rider recording.
 *
 * It looks for:
 *  - the bright yellow road edge in the lower half of the frame;
 *  - the colorful player/cart in the center-left playfield;
 *  - the cart's principal-axis angle.
 *
 * Output is deliberately simple: LEFT, RIGHT or NONE. A small hysteresis and
 * temporal filter stop single noisy frames from producing rapid button taps.
 */
object PudgeAnalyzer {
    enum class Action { NONE, LEFT, RIGHT }

    data class Decision(
        val action: Action,
        val confidence: Float,
        val angleDeg: Float,
        val airborne: Boolean,
        val playerX: Float,
        val playerY: Float,
        val roadY: Float
    )

    private var filteredAngle = 0f
    private var lastAction = Action.NONE
    private var stableFrames = 0

    @Synchronized
    fun reset() {
        filteredAngle = 0f
        lastAction = Action.NONE
        stableFrames = 0
    }

    @Synchronized
    fun decide(bitmap: Bitmap, sensitivity: Float): Decision {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 200 || h < 400) return Decision(Action.NONE, 0f, 0f, false, .5f, .55f, .65f)

        val road = findRoad(bitmap)
        val player = findPlayer(bitmap)
        if (player == null) {
            stableFrames = max(0, stableFrames - 1)
            return Decision(Action.NONE, 0f, filteredAngle, false, .42f, .52f, road)
        }

        // PCA gives the dominant axis of the colorful player/cart cluster.
        var angle = -atan2(player.dy, player.dx) * 180f / Math.PI.toFloat()
        // PCA has a 180° ambiguity. The cart normally points toward the right,
        // so normalize to the useful -90..90 interval.
        while (angle > 90f) angle -= 180f
        while (angle < -90f) angle += 180f
        filteredAngle = filteredAngle * .72f + angle * .28f

        val roadAtPlayer = roadAtX(player.cx, road, h)
        val playerBottom = player.maxY
        val gap = (roadAtPlayer - playerBottom) / h
        val airborne = gap > (0.018f + (1f - sensitivity) * 0.008f)

        // Positive angle = nose is higher on the right. In Hill-Climb-style
        // controls, the right pedal rotates the vehicle clockwise (nose down),
        // while the left pedal rotates it counter-clockwise (nose up).
        val deadZone = 5.5f - sensitivity * 2.0f
        val strongZone = 12.0f - sensitivity * 3.0f
        val wanted = when {
            filteredAngle > strongZone -> Action.RIGHT
            filteredAngle < -strongZone -> Action.LEFT
            airborne && filteredAngle > deadZone -> Action.RIGHT
            airborne && filteredAngle < -deadZone -> Action.LEFT
            else -> Action.NONE
        }

        if (wanted == lastAction && wanted != Action.NONE) stableFrames++
        else if (wanted != Action.NONE) { stableFrames = 1; lastAction = wanted }
        else { stableFrames = max(0, stableFrames - 1); lastAction = Action.NONE }

        val confidence = min(1f, (abs(filteredAngle) / 24f) * .8f + if (airborne) .2f else 0f)
        val action = if (stableFrames >= 2) wanted else Action.NONE
        return Decision(action, confidence, filteredAngle, airborne, player.cx / w, player.cy / h, roadAtPlayer / h)
    }

    private data class PlayerCluster(
        val cx: Float, val cy: Float, val minY: Int, val maxY: Int,
        val dx: Float, val dy: Float
    )

    private fun findPlayer(bitmap: Bitmap): PlayerCluster? {
        val w = bitmap.width
        val h = bitmap.height
        val x0 = (w * .05f).toInt()
        val x1 = (w * .68f).toInt()
        val y0 = (h * .34f).toInt()
        val y1 = (h * .69f).toInt()
        val step = max(2, w / 180)

        var sumX = 0.0
        var sumY = 0.0
        var sumXX = 0.0
        var sumYY = 0.0
        var sumXY = 0.0
        var minY = h
        var maxY = 0
        var count = 0

        for (y in y0 until y1 step step) {
            for (x in x0 until x1 step step) {
                val p = bitmap.getPixel(x, y)
                val r = (p ushr 16) and 255
                val g = (p ushr 8) and 255
                val b = p and 255
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                val lum = (r + g + b) / 765f
                val sat = (mx - mn) / 255f

                // Player/cart colors in the recording are much more saturated
                // than the dark purple background. Exclude the very bright HUD.
                val hit = sat > .25f && lum > .18f && lum < .82f
                if (!hit) continue

                count++
                sumX += x
                sumY += y
                sumXX += x.toDouble() * x
                sumYY += y.toDouble() * y
                sumXY += x.toDouble() * y
                minY = min(minY, y)
                maxY = max(maxY, y)
            }
        }
        if (count < 25) return null

        val cx = sumX / count
        val cy = sumY / count
        val cxx = sumXX / count - cx * cx
        val cyy = sumYY / count - cy * cy
        val cxy = sumXY / count - cx * cy
        val theta = .5 * atan2(2.0 * cxy, cxx - cyy)
        val dx = cos(theta).toFloat()
        val dy = sin(theta).toFloat()
        return PlayerCluster(cx.toFloat(), cy.toFloat(), minY, maxY, dx, dy)
    }

    private fun findRoad(bitmap: Bitmap): Float {
        val w = bitmap.width
        val h = bitmap.height
        val x0 = (w * .02f).toInt()
        val x1 = (w * .98f).toInt()
        val y0 = (h * .48f).toInt()
        val y1 = (h * .72f).toInt()
        val step = max(2, w / 160)

        var sumY = 0.0
        var n = 0
        for (x in x0 until x1 step step) {
            var bestY = -1
            var bestScore = 0
            for (y in y0 until y1 step step) {
                val p = bitmap.getPixel(x, y)
                val r = (p ushr 16) and 255
                val g = (p ushr 8) and 255
                val b = p and 255
                val score = r + g - b
                if (r > 135 && g > 95 && b < 130 && r > b * 1.35f && score > bestScore) {
                    bestScore = score
                    bestY = y
                }
            }
            if (bestY >= 0) { sumY += bestY; n++ }
        }
        return if (n >= 10) (sumY / n).toFloat() else h * .64f
    }

    private fun roadAtX(x: Float, roadMean: Float, h: Int): Float {
        // The supplied recording has a gently varying road line. The mean is a
        // safe baseline; the player/airborne detector only needs a coarse gap.
        return roadMean.coerceIn(h * .50f, h * .72f)
    }
}
