package com.example.pangorushbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object { var instance: BotAccessibilityService? = null }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun pressLeft(duration: Long = 85L) = pressAt(.17f, duration)
    fun pressRight(duration: Long = 85L) = pressAt(.83f, duration)

    private fun pressAt(xNorm: Float, duration: Long) {
        if (BotState.status != BotStatus.RUNNING) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels * xNorm
        // Pudge Rider recording: the two controls sit around 68% of screen height.
        val y = dm.heightPixels * .68f
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
