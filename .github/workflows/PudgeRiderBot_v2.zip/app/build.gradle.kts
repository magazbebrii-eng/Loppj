plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pangorushbot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.pangorushbot"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "2.0"
    }
}
