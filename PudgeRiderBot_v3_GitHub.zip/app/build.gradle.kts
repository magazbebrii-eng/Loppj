plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pangorushbot"
    compileSdk = 35

    // Java and Kotlin must use the same JVM target on GitHub Actions.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.example.pangorushbot"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "2.0"
    }
}
